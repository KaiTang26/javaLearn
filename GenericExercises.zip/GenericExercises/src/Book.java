
public interface Book {
	
	
	@Override
	public String toString();
	

}
