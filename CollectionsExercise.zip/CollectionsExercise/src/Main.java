
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Exercise.Question5("HELLO, hello There THERE"));

	}

}
